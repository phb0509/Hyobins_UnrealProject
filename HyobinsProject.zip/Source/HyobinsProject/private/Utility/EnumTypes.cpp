// Fill out your copyright notice in the Description page of Project Settings.


#include "Utility/EnumTypes.h"


AEnumTypes::AEnumTypes()
{
	PrimaryActorTick.bCanEverTick = false;

}

void AEnumTypes::BeginPlay()
{
	Super::BeginPlay();
	
}

void AEnumTypes::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

