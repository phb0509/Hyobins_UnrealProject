// Fill out your copyright notice in the Description page of Project Settings.


#include "LevelBase.h"


ALevelBase::ALevelBase()
{
	UE_LOG(LogTemp, Warning, TEXT("LevelBase :: Constructor"));
}

